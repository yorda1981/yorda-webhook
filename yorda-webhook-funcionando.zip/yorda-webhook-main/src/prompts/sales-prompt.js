// Prompt vendedor
